import csv
import os, glob
import sys
import xlsxwriter

if __name__ == '__main__':
    s1 = "ab.cd.ef.g"
    print s1.find('.')
    print s1.rindex('.')
    # listOfFiles = os.listdir(directory)           #  list of all files in the directory
    listOfFiles = glob.glob("I:/*.csv")
    for index, fileInList in enumerate(listOfFiles):
        fileName = fileInList[0:fileInList.rindex('.')]
        excelFile = xlsxwriter.Workbook(fileName + '.xlsx')
        print fileName
        worksheet = excelFile.add_worksheet()
        # with open(fileName + ".csv", 'rb') as f:
        with open(fileInList, 'rb') as f:
            content = csv.reader(f)
            # for index_row, data_in_row in enumerate(content):
            #     for index_col, data_in_cell in enumerate(data_in_row):
            #         worksheet.write(index_row, index_col, data_in_cell)

    excelFile.close()
    print " === Conversion is done ==="
