import os
import glob
import csv
import sys
# from openpyxl import Workbook
from xlsxwriter.workbook import Workbook

# reload(sys)
# sys.setdefaultencoding('utf-8')

for csvfile in glob.glob(os.path.join('I:/', '*.csv')):
    workbook = Workbook(csvfile + '00.xlsx')
    worksheet = workbook.add_worksheet()
    with open(csvfile, 'rb') as f:
        # reader = csv.reader(f)
        data = f.read()
        data.strip()

        # for r, row in enumerate(reader):
        r = 0
        for row in data.split('\n'):
            print row, ":", r, ":"
            for c, col in enumerate(row):
                print col, ":", c
                if r > 0: worksheet.write(r, c, col)
            r += 1
    workbook.close()
