# -*- coding: utf-8 -*- 

import xlrd


def open_excel(file_name='applied.xlsx'):
    try:
        data = xlrd.open_workbook(file_name)
        return data
    except Exception, e:
        print str(e)


def excel_table_by_index(file_name='applied.xlsx', column_index=0, by_index=0):
    data = open_excel(file_name)
    table = data.sheets()[by_index]
    nrows = table.nrows
    col_names = table.row_values(column_index)
    info_list = []
    for row_num in range(1, nrows):
        row = table.row_values(row_num)
        if row:
            app = {}
            for i in range(len(col_names)):
                if isinstance(row[i], unicode):
                    var = row[i]
                else:
                    var = str(row[i]).decode('utf-8')
                # app[col_names[i]] = var.encode('utf-8')
                app[col_names[i]] = var
            info_list.append(app)
    return info_list


def excel_table_by_name(file_name='applied.xlsx', column_index=0, by_name='Sheet1'):
    data = open_excel(file_name)
    table = data.sheet_by_name(by_name)
    nrows = table.nrows
    col_names = table.row_values(column_index)
    info_list = []
    for row_num in range(1, nrows):
        row = table.row_values(row_num)
        if row:
            app = {}
            for i in range(len(col_names)):
                if isinstance(row[i], unicode):
                    var = row[i]
                else:
                    var = str(row[i]).decode('utf-8')
                app[col_names[i]] = var
            info_list.append(app)
    return info_list


def main():
    s = u'中文'
    print s.encode('utf-8')
    s2 = '中国'
    print s2
    s3 = s2.decode('utf-8')
    print s3
    print s3.encode('utf-8')
    s4 = '\u4e2d'
    print s4, "!"
    print s4.decode('unicode_escape')
    print isinstance(s4.decode('unicode_escape'), unicode)
    print s4.decode('unicode_escape').encode('utf-8')
    print "——————————————————————————————————"

    tables = excel_table_by_index()
    for row in tables:
        print isinstance(row['component'], unicode), \
            isinstance(row['version'], unicode), isinstance(row['file'], unicode)
        print row['component'].encode('utf-8'), \
            row['version'].encode('utf-8'), row['file'].encode('utf-8')
    print "——————————————————————————————————"

    tables = excel_table_by_name()
    for row in tables:
        print row['component'].encode('utf-8'), \
            row['version'].encode('utf-8'), row['file'].encode('utf-8')


if __name__ == "__main__":
    main()
