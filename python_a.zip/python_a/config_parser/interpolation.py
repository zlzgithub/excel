import ConfigParser

cp = ConfigParser.SafeConfigParser()
cp.read('interpolation.conf')

print cp.get('http', 'url')  # http://localhost:8080/
print cp.get('ftp', 'url')  # ftp://192.168.1.102/
