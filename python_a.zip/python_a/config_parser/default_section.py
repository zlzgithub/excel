import ConfigParser

cp = ConfigParser.SafeConfigParser()
cp.read('default_section.conf')
print cp.get('db_root', 'host')  # 127.0.0.1
print cp.get('db_huey', 'host')  # 192.168.1.101
