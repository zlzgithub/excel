from configobj import ConfigObj
config = ConfigObj('test_config.cfg')
#
value1 = config['keyword1']
value2 = config['keyword2']
print value1
print value2
#
section1 = config['section 1']
value3 = section1['keyword3']
value4 = section1['keyword4']
print value3
print value4
#
# you could also write
value5 = config['section 1']['keyword3']
value6 = config['section 1']['keyword4']



print value5
print value6
