import ConfigParser
import codecs

cp = ConfigParser.SafeConfigParser()
with codecs.open('config_parser_unicode.conf', 'r', encoding='utf-8') as f:
    cp.readfp(f)

print cp.get('msg', 'hello')
