import ConfigParser

cp = ConfigParser.SafeConfigParser()
cp.read('interpolation.conf')

