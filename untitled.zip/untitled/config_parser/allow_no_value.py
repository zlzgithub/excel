import ConfigParser

cp = ConfigParser.SafeConfigParser(allow_no_value = True)
cp.read('allow_no_value.conf')
print cp.get('flag', 'flag_opt');    # None