import ConfigParser
import sys

cp = ConfigParser.SafeConfigParser()
cp.read('interpolation.conf')

print type(cp.getint('http', 'port'))

cp.set('ftp', 'server', '192.168.1.101')

if not cp.has_section('https'):
    cp.add_section('https')
    cp.set('https', 'protocol', 'https')

if not cp.has_option('https', 'protocol'):
    cp.set('https', 'protocol', 'https')

cp.remove_option('https', 'url')
cp.set('https', 'url', 'https://baidu.com/')

cp.write(open('interpolation.conf', 'w'))
cp.write(sys.stdout)
