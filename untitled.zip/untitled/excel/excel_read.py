import xlrd
import re


def cal():
    name_version_dic = {}
    name_version_dic2 = {}
    data = xlrd.open_workbook('applied.xlsx')
    print data.sheets()[0].name
    sheet = data.sheets()[0]
    sheet2 = data.sheets()[1]

    # dic 1
    print "============================================"
    n_rows = sheet.nrows
    n_cols = sheet.ncols
    print n_rows
    print range(0, n_rows)

    for i in range(0, n_rows):
        for j in range(0, n_cols):
            print sheet.row_values(i)[j],
            if (j + 1) % n_cols == 0:
                print ""

    for i in range(1, n_rows):
        name_version_dic[sheet.row_values(i)[1]] = sheet.row_values(i)[2]

    print "============================================"
    print len(name_version_dic)
    print name_version_dic

    # dic 2
    print "============================================2"
    n_rows2 = sheet2.nrows
    n_cols2 = sheet2.ncols
    print n_rows2
    print range(0, n_rows2)

    for i in range(0, n_rows2):
        for j in range(0, n_cols2):
            print sheet2.row_values(i)[j],
            if (j + 1) % n_cols2 == 0:
                print ""

    for i in range(1, n_rows2):
        name_version_dic2[sheet2.row_values(i)[0]] = sheet2.row_values(i)[1]

    print "============================================"
    print len(name_version_dic2)
    print name_version_dic2

    not_yet_applied_dic = {}
    str_applied_all = ""

    # compare
    print "============================================3"
    if name_version_dic is not None:
        for k in name_version_dic.keys():
            if name_version_dic2.has_key(k):
                if name_version_dic[k] != name_version_dic2[k]:
                    not_yet_applied_dic[k] = name_version_dic[k]
            else:
                print "has not"
                not_yet_applied_dic[k] = name_version_dic[k]

    # result
    print "============================================4"
    print not_yet_applied_dic
    for k in not_yet_applied_dic.keys():
        print k.encode('utf-8') + ": " + str(not_yet_applied_dic[k])


def read_file():
    f = open("applied.txt", "r")
    txt = f.read()
    f.close()
    return txt


def str_in_file(str1):
    p = re.compile('\.')
    str1 = p.sub("_", str1)
    p = re.compile('\W+')
    str1 = p.sub(" ", str1)
    p = re.compile('^\s+|\s+$')
    str1 = p.sub("", str1)
    p = re.compile('_')
    str1 = p.sub("\\.", str1)
    p = re.compile("\s+")
    str1 = p.sub("\\W{1,9}", str1)
    print str1

    p = re.compile("str1")
    print "???"
    # print p.match(read_file(), 0)
    # print re.match('Spring', "spring framework 1.1 ++", re.IGNORECASE) is None
    print re.search('Spring ')


def main():
    print read_file()
    print "==="
    print str_in_file("spring framework 1.1")


if __name__ == "__main__":
    main()
